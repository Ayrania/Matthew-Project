﻿using System;
using System.Net.Sockets;
using System.Text;

class client
{
    static void Main()
    {
        string genre = "fiction";
        string serverIP = "127.0.0.1";
        int port = 8888;

        string responseData = SendRequestToServer(serverIP, port, genre);

        // Process the response data (e.g., deserialize JSON and extract book details)
        // For this example, we'll just print the response data
        Console.WriteLine(responseData);
        while (true)
        {

        }
    }

    private static string SendRequestToServer(string serverIP, int port, string genre)
    {
        try
        {
            // Connect to the server
            TcpClient client = new TcpClient(serverIP, port);
            Console.WriteLine("Connected to the server.");

            // Prepare the request data with the genre
            string requestData = $"[Genre=\"{genre}\"]";

            // Convert the request data to bytes and send it to the server
            byte[] requestBytes = Encoding.ASCII.GetBytes(requestData);
            NetworkStream stream = client.GetStream();
            stream.Write(requestBytes, 0, requestBytes.Length);
            Console.WriteLine("Request sent to the server.");

            // Buffer to store incoming data
            byte[] buffer = new byte[1024];

            // Read the response from the server
            int bytesRead = stream.Read(buffer, 0, buffer.Length);

            // Convert the received data to a string (assuming ASCII encoding)
            string responseData = Encoding.ASCII.GetString(buffer, 0, bytesRead);

            // Close the client connection
            client.Close();
            Console.WriteLine("Client disconnected.");

            return responseData;
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
            return null;
        }
    }
}