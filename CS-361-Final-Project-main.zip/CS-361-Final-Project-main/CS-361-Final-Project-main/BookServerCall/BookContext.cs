﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

class BookContext
{
    static void Main()
    {
        StartServer();
    }

    private static void StartServer()
    {
        // Set up server IP and port
        string serverIP = "127.0.0.1";
        int port = 8888;

        // Create a TCP listener
        TcpListener listener = new TcpListener(IPAddress.Parse(serverIP), port);

        try
        {
            // Start listening for incoming client requests
            listener.Start();
            Console.WriteLine($"Server started. Listening on {serverIP}:{port}");

            while (true)
            {
                // Accept incoming client connections
                TcpClient client = listener.AcceptTcpClient();
                Console.WriteLine("Client connected.");

                // Handle client request in a separate thread
                System.Threading.ThreadPool.QueueUserWorkItem(HandleClient, client);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
        finally
        {
            // Stop listening for incoming connections
            listener.Stop();
        }
    }

    private static void HandleClient(object clientObj)
    {
        using (TcpClient client = (TcpClient)clientObj)
        {
            try
            {
                // Get the network stream from the client
                NetworkStream stream = client.GetStream();

                // Buffer to store incoming data
                byte[] buffer = new byte[1024];

                // Read the incoming data from the client
                int bytesRead = stream.Read(buffer, 0, buffer.Length);

                // Convert the received data to a string (assuming ASCII encoding)
                string requestData = Encoding.ASCII.GetString(buffer, 0, bytesRead);

                // Extract the genre from the request data
                string genre = ExtractGenre(requestData);

                // Here, you can implement the logic to fetch book data based on the genre
                // For demonstration purposes, we'll just hard-code some book data
                if (genre.toLower() == "fiction")
                {
                    responseData = @"{
                    ""Author"": ""Suzanne Collins"",
                    ""Description"": ""Winning will make you famous. Losing means certain death....(full description)..."",
                    ""Edition"": ""Hardcover"",
                    ""Isbn"": ""9.78E+12"",
                    ""PageCount"": ""374 pages"",
                    ""Rating"": ""4.33"",
                    ""Title"": ""The Hunger Games"",
                    ""Genre"": ""Young Adult|Fiction|Science Fiction|Dystopia|Fantasy|Science Fiction"",
                    ""ImageUrl"": ""https://images.gr-assets.com/books/1447303603l/2767052.jpg""
                }";
                }
                else if (genre.ToLower() == "classics")
                {
                    responseData = @"{
                    ""Author"": ""Harper Lee"",
                    ""Description"": ""The unforgettable novel of a childhood in a sleepy Southern town and the crisis of conscience that rocked it....(full description)..."",
                    ""Edition"": ""Paperback"",
                    ""Isbn"": ""9780060000000"",
                    ""PageCount"": ""324 pages"",
                    ""Rating"": ""4.27"",
                    ""Title"": ""To Kill a Mockingbird"",
                    ""Genre"": ""Classics|Fiction|Historical|Historical Fiction|Academic|School"",
                    ""ImageUrl"": ""https://images.gr-assets.com/books/1361975680l/2657.jpg""
                }";

                }
                else
                {
                    responseData = "Genre not recognized.";
                }



                // Prepare the response data with book details
                string responseData = $"[Author=\"{author}\", Description=\"{description}\", Edition=\"{edition}\", Rating=\"{rating}\"]";

                // Convert the response data to bytes and send it back to the client
                byte[] responseBytes = Encoding.ASCII.GetBytes(responseData);
                stream.Write(responseBytes, 0, responseBytes.Length);

                // Close the client connection
                client.Close();
                Console.WriteLine("Client disconnected.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error handling client: " + ex.Message);
            }
        }
    }

    private static string ExtractGenre(string requestData)
    {
        // Extract the genre from the request data (assuming a simple format)
        // You may need to modify this based on the actual request format you are using
        int startIndex = requestData.IndexOf("[Genre=\"") + "[Genre=\"".Length;
        int endIndex = requestData.IndexOf("\"]");
        return requestData.Substring(startIndex, endIndex - startIndex);
    }
}
